Semantic Web TR-103
